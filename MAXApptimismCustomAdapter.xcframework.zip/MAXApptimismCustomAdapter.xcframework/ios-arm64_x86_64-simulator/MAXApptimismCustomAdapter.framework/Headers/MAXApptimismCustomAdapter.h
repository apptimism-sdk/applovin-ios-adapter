//
//  MAXApptimismCustomAdapter.h
//  MAXApptimismCustomAdapter
//
//  Created by daniyal.devetov on 29/10/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for MAXApptimismCustomAdapter.
FOUNDATION_EXPORT double MAXApptimismCustomAdapterVersionNumber;

//! Project version string for MAXApptimismCustomAdapter.
FOUNDATION_EXPORT const unsigned char MAXApptimismCustomAdapterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MAXApptimismCustomAdapter/PublicHeader.h>


